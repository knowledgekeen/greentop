import { SearchclientPipe } from './searchclient.pipe';

describe('SearchclientPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchclientPipe();
    expect(pipe).toBeTruthy();
  });
});
