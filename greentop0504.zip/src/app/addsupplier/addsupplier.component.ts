import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addsupplier',
  templateUrl: './addsupplier.component.html',
  styleUrls: ['./addsupplier.component.css']
})
export class AddsupplierComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
