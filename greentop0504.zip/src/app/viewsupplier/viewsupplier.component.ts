import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewsupplier',
  templateUrl: './viewsupplier.component.html',
  styleUrls: ['./viewsupplier.component.css']
})
export class ViewsupplierComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
