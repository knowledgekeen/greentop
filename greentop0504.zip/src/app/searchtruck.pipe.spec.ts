import { SearchtruckPipe } from './searchtruck.pipe';

describe('SearchtruckPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchtruckPipe();
    expect(pipe).toBeTruthy();
  });
});
