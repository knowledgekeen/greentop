<?php
//Create a connection
header('Access-Control-Allow-Origin: *');
//$conn = new mysqli("localhost", "assasate_gto", "Assasa@123", "assasate_greentop");
$conn = new mysqli("localhost", "root", "", "greentop");
?>